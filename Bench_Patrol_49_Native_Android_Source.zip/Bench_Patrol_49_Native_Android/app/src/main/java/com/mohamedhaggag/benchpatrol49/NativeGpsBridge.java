package com.mohamedhaggag.benchpatrol49;

import android.webkit.JavascriptInterface;

/** Narrow JavaScript bridge: only the packaged app page calls these methods. */
public final class NativeGpsBridge {
    private final MainActivity activity;

    NativeGpsBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void startTracking() {
        activity.runOnUiThread(activity::requestNativeGps);
    }

    @JavascriptInterface
    public void stopTracking() {
        activity.runOnUiThread(activity::stopNativeGps);
    }
}
