package com.mohamedhaggag.benchpatrol49;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.Priority;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQUEST_LOCATION = 7301;
    private static final int REQUEST_LOCATION_SETTINGS = 7302;
    private static final String APP_ASSET_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;
    private boolean permissionRequestPending = false;
    private long lastLocationTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8, 23, 37));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8, 23, 37));

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        buildLocationRequest();
        buildWebView();
    }

    private void buildLocationRequest() {
        // High accuracy, continuous updates. Android treats the cadence as a best-effort request.
        locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(500L)
                .setMinUpdateDistanceMeters(0f)
                .setMaxUpdateAgeMillis(0L)
                .setWaitForAccurateLocation(false)
                .build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult result) {
                if (result.getLocations() == null) return;
                for (Location location : result.getLocations()) {
                    long timestamp = location.getTime();
                    if (timestamp <= lastLocationTime) continue;
                    long age = Math.max(0L, System.currentTimeMillis() - timestamp);
                    // Do not replace a fresh fix with an old cached point.
                    if (age > 10000L) continue;
                    lastLocationTime = timestamp;
                    sendLocationToPage(location);
                }
            }
        };
    }

    private void buildWebView() {
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        webView.addJavascriptInterface(new NativeGpsBridge(this), "BenchNativeGPS");
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if ("appassets.androidplatform.net".equalsIgnoreCase(host)) return false;
                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme) || "google.navigation".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) { }
                    return true;
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl(APP_ASSET_URL);
    }

    void requestNativeGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (!permissionRequestPending) {
                permissionRequestPending = true;
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, REQUEST_LOCATION);
            }
            return;
        }
        verifyLocationSettingsThenStart();
    }

    private void verifyLocationSettingsThenStart() {
        LocationSettingsRequest request = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)
                .setAlwaysShow(true)
                .build();
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = settingsClient.checkLocationSettings(request);
        task.addOnSuccessListener(response -> startLocationUpdates());
        task.addOnFailureListener(error -> {
            if (error instanceof ResolvableApiException) {
                try {
                    ((ResolvableApiException) error).startResolutionForResult(this, REQUEST_LOCATION_SETTINGS);
                } catch (Exception e) {
                    sendGpsError(2);
                }
            } else {
                sendGpsError(2);
            }
        });
    }

    private void startLocationUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            sendGpsError(1);
            return;
        }
        lastLocationTime = 0L;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
                .addOnFailureListener(error -> sendGpsError(2));
    }

    void stopNativeGps() {
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void sendLocationToPage(Location location) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("latitude", location.getLatitude());
            payload.put("longitude", location.getLongitude());
            payload.put("accuracy", (double) location.getAccuracy());
            if (android.os.Build.VERSION.SDK_INT >= 26 && location.hasBearing()) {
                payload.put("heading", (double) location.getBearing());
            } else {
                payload.put("heading", JSONObject.NULL);
            }
            if (android.os.Build.VERSION.SDK_INT >= 26 && location.hasSpeed()) {
                payload.put("speed", (double) location.getSpeed());
            } else {
                payload.put("speed", JSONObject.NULL);
            }
            payload.put("timestamp", location.getTime());
        } catch (JSONException ignored) {
            return;
        }
        String script = "window.onNativeGpsFix && window.onNativeGpsFix(" + payload + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private void sendGpsError(int code) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("window.onNativeGpsError && window.onNativeGpsError(" + code + ");", null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            permissionRequestPending = false;
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                verifyLocationSettingsThenStart();
            } else {
                sendGpsError(1);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LOCATION_SETTINGS) {
            if (resultCode == RESULT_OK) verifyLocationSettingsThenStart();
            else sendGpsError(2);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("if(document.getElementById('app')?.classList.contains('map-focus')){document.getElementById('exitMapBtn')?.click();}", null);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        stopNativeGps();
        if (webView != null) {
            webView.removeJavascriptInterface("BenchNativeGPS");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
