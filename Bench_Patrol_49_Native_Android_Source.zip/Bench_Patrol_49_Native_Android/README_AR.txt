Bench Patrol 49 — Native Android GPS
Created & owned by Mohamed Haggag

WHAT THIS PROJECT DOES
- Keeps the existing Bench Patrol 49 interface, 49 original checkpoint coordinates, Arabic/English UI, ownership text, map, route drawing, completion status, and restart controls.
- Adds a native Android location bridge using Google Play services FusedLocationProviderClient.
- Requests high-accuracy location updates with a 1,000 ms desired interval, 500 ms fastest allowed interval, zero minimum displacement, and no historical initial fix.
- Sends each fresh Android location fix into the existing JavaScript map UI.
- Uses WebViewAssetLoader so the packaged HTML is served from an HTTPS-like appassets origin, not file://.

IMPORTANT LIMITS
- Android location intervals are best-effort. Android/Google Play services, phone power settings, GPS visibility, and environment decide actual callback timing and accuracy. A one-second interval is requested, not guaranteed.
- The app keeps the screen awake while native tracking is active. This starter project does not implement a persistent background foreground-service, so keep the app open in the foreground while patrolling for the most reliable updates.
- MapLibre assets, OpenStreetMap tiles, and OSRM routing still require internet. OSRM's public demo endpoint is not an SLA-backed production service.
- The app requires Google Play services on the phone for FusedLocationProviderClient.

BUILD REQUIREMENTS
- Android Studio with Android SDK Platform 36.
- JDK 17 or newer (JDK 17 is the configured Java source target).
- Android Gradle Plugin 8.13.2 / Gradle 8.13.
- Dependencies: AndroidX WebKit 1.18.0 and Google Play services Location 21.4.0.
- Internet during the first build to download Gradle and Maven dependencies.

BUILD APK
1. Open the Bench_Patrol_49_Native_Android folder in Android Studio.
2. Allow Gradle sync and SDK/dependency downloads to finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.
5. Copy the APK to the Samsung phone and install it. Android may ask to allow installing unknown apps for the file manager/browser.

PHONE PERMISSIONS
- On first use, tap Start GPS and choose Precise location / Allow while using the app.
- Keep Location enabled and disable battery saver during patrol.
- The app asks Android to enable the high-accuracy location settings if they are off.

PACKAGE
- Application ID: com.mohamedhaggag.benchpatrol49
- Display name: Bench Patrol 49
- Version: 2.0-native-gps
- Owner notice in the app: Designed, developed & owned by Mohamed Haggag.

This is an Android Studio source project, not a compiled APK. It must be built with Android SDK/Gradle before installation.
