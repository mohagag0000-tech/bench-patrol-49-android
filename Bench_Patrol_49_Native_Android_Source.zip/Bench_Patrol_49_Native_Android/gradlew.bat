@echo off
set VERSION=8.13
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (gradle %* & exit /b %ERRORLEVEL%)
set BASE=%USERPROFILE%\.gradle\manual-wrapper\gradle-%VERSION%
if not exist "%BASE%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\manual-wrapper" mkdir "%USERPROFILE%\.gradle\manual-wrapper"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%TEMP%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%TEMP%\gradle-%VERSION%-bin.zip' '%USERPROFILE%\.gradle\manual-wrapper'"
)
call "%BASE%\bin\gradle.bat" %*
